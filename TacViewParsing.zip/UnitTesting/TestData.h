#pragma once
#include <iostream>
#include <string>

// Array of fixed messages for testing
extern const std::string messages[];